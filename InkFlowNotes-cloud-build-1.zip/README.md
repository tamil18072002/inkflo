# InkFlow Notes — MVP starter

InkFlow Notes is a native Android tablet app starter for stylus notes and PDF markup.

## MVP currently included in source
- Kotlin + Jetpack Compose Android project.
- Native Android `View` drawing surface for stylus events.
- Pressure values recorded per point and used as input data; variable-width pressure rendering is not yet implemented.
- Pen, highlighter, stroke-level eraser, undo, color presets, and brush size.
- Local JSON note persistence and recent-notes list.
- PDF import using Android's document picker.
- First-page PDF rendering using `PdfRenderer`.
- Vector annotation export to a new PDF copy using PDFBox Android.
- Stylus input diagnostics for tool type, pressure, and button-state changes.
- A small JSON round-trip unit test.

## Known MVP limitations (do not treat as completed features)
- PDF display/export currently covers page 1 only.
- The PDF exporter maps normalized strokes to the PDF crop box; complex page rotations, crop offsets, and annotation placement on PDFs with unusual page geometry need additional tests.
- The current eraser removes an entire nearby stroke rather than partially erasing it.
- Pressure is captured but does not yet change stroke width.
- The highlighter is a translucent-looking stroke in the editor; export uses vector alpha where supported.
- The primary stylus button event is currently wired to undo only as a proof of concept. The secondary button is not mapped yet. Actual REDMI Smart Pen 1S events must be verified on physical hardware.
- No layers, text objects, handwriting OCR, multi-page navigation, Room database, cloud sync, or brush engine yet.
- The current app uses local JSON files for the MVP. A later milestone can migrate metadata to Room without changing the drawing document format.

## Build
1. Install Android Studio and a JDK 17.
2. Open this folder in Android Studio.
3. Allow Gradle to sync and download dependencies.
4. Build with **Build > Make Project**.
5. Connect the Redmi tablet with USB debugging enabled and accept the debugging prompt.
6. Run the `app` configuration, or build an APK with:
   `./gradlew assembleDebug`
7. Install with:
   `adb install -r app/build/outputs/apk/debug/app-debug.apk`

No build has been run in the generation environment. Treat this as source to build and validate, not as a verified APK.

## Physical device test checklist
- Create a note, draw several strokes, save, close/reopen the note.
- Test pen tip, finger, and palm behavior.
- Check pressure values while varying pen pressure.
- Press each physical pen button with the tip touching the canvas and inspect the diagnostic string.
- Import a PDF, annotate page 1, export to a new PDF, and verify text remains selectable.
- Test a long note and a large PDF for memory use.
- Confirm the original PDF remains unchanged.

## Architecture
- `model/InkModels.kt`: document and stroke models + JSON codec.
- `data/NoteRepository.kt`: local note storage.
- `data/PdfRepository.kt`: PDF import, render, and vector export.
- `ui/DrawingSurface.kt`: stylus input and rendering.
- `MainActivity.kt`: workspace UI and feature wiring.

## Suggested next milestones
1. Make pressure influence stroke width and implement better smoothing.
2. Implement undo/redo as a command history, then partial erasing.
3. Add robust PDF page navigation and page-specific annotation documents.
4. Implement persistent button profiles for drawing/notes/PDF after validating real input events.
5. Add Room for notebooks/folders/tags and introduce a brush/layer renderer.
