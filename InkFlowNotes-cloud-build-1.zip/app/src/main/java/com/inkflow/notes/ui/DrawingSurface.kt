package com.inkflow.notes.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import com.inkflow.notes.model.InkPoint
import com.inkflow.notes.model.InkStroke
import com.inkflow.notes.model.InkTool
import kotlin.math.hypot

class DrawingSurface(context: Context) : View(context) {
    var strokes: MutableList<InkStroke> = mutableListOf()
        set(value) { field = value; invalidate() }
    var activeColor: Int = Color.BLACK
    var brushWidthDp: Float = 3.0f
    var activeTool: InkTool = InkTool.PEN
    var backgroundBitmap: Bitmap? = null
        set(value) { field = value; invalidate() }
    var onStrokesChanged: ((List<InkStroke>) -> Unit)? = null
    var onInputDiagnostic: ((String) -> Unit)? = null
    var onUndoRequested: (() -> Unit)? = null
    private var currentPoints = mutableListOf<InkPoint>()
    private var lastButtonState = 0
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val contentRect = RectF()

    init {
        setLayerType(View.LAYER_TYPE_HARDWARE, null)
        isFocusable = true
    }

    private fun updateContentRect() {
        val bitmap = backgroundBitmap
        if (bitmap == null || width == 0 || height == 0) {
            contentRect.set(0f, 0f, width.toFloat(), height.toFloat())
            return
        }
        val scale = minOf(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
        val w = bitmap.width * scale
        val h = bitmap.height * scale
        contentRect.set((width - w) / 2f, (height - h) / 2f, (width + w) / 2f, (height + h) / 2f)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.WHITE)
        updateContentRect()
        backgroundBitmap?.let { canvas.drawBitmap(it, null, contentRect, bitmapPaint) }
        // Simple paper guide for note mode.
        if (backgroundBitmap == null) {
            val guide = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(226, 233, 242)
                strokeWidth = resources.displayMetrics.density
            }
            var y = 48f * resources.displayMetrics.density
            while (y < height) {
                canvas.drawLine(0f, y, width.toFloat(), y, guide)
                y += 32f * resources.displayMetrics.density
            }
        }
        strokes.forEach { drawStroke(canvas, it) }
        if (currentPoints.isNotEmpty()) {
            drawStroke(canvas, InkStroke(currentPoints.toList(), activeColor, brushWidthDp, activeTool))
        }
    }

    private fun drawStroke(canvas: Canvas, stroke: InkStroke) {
        if (stroke.points.isEmpty()) return
        val path = Path()
        val first = stroke.points.first()
        path.moveTo(contentRect.left + first.x * contentRect.width(), contentRect.top + first.y * contentRect.height())
        stroke.points.drop(1).forEach { point ->
            path.lineTo(contentRect.left + point.x * contentRect.width(), contentRect.top + point.y * contentRect.height())
        }
        strokePaint.color = when (stroke.tool) {
            InkTool.HIGHLIGHTER -> (stroke.color and 0x00FFFFFF) or 0x55000000
            else -> stroke.color
        }
        strokePaint.xfermode = null
        if (stroke.points.size == 1) {
            val p = stroke.points[0]
            val x = contentRect.left + p.x * contentRect.width()
            val y = contentRect.top + p.y * contentRect.height()
            strokePaint.strokeWidth = stroke.widthDp * resources.displayMetrics.density * p.pressure.coerceIn(0.15f, 1.5f)
            canvas.drawCircle(x, y, strokePaint.strokeWidth / 2f, Paint(strokePaint).apply { style = Paint.Style.FILL })
        } else {
            // Segment-level pressure rendering keeps the first MVP lightweight while preserving pressure variation.
            val density = resources.displayMetrics.density
            for (i in 1 until stroke.points.size) {
                val a = stroke.points[i - 1]
                val b = stroke.points[i]
                val pressure = ((a.pressure + b.pressure) / 2f).coerceIn(0.15f, 1.5f)
                strokePaint.strokeWidth = stroke.widthDp * density * pressure
                canvas.drawLine(
                    contentRect.left + a.x * contentRect.width(), contentRect.top + a.y * contentRect.height(),
                    contentRect.left + b.x * contentRect.width(), contentRect.top + b.y * contentRect.height(), strokePaint
                )
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val index = event.actionIndex.coerceIn(0, event.pointerCount - 1)
        val toolType = event.getToolType(index)
        val buttons = event.buttonState
        onInputDiagnostic?.invoke(
            "tool=${if (toolType == MotionEvent.TOOL_TYPE_STYLUS) "STYLUS" else if (toolType == MotionEvent.TOOL_TYPE_FINGER) "FINGER" else toolType.toString()} · pressure=${"%.2f".format(event.getPressure(index))} · buttons=0x${buttons.toString(16)}"
        )
        if (buttons != lastButtonState) {
            if ((buttons and MotionEvent.BUTTON_STYLUS_PRIMARY) != 0) onUndoRequested?.invoke()
            onInputDiagnostic?.invoke("Button state changed: 0x${buttons.toString(16)}")
            lastButtonState = buttons
        }
        if (toolType != MotionEvent.TOOL_TYPE_STYLUS && toolType != MotionEvent.TOOL_TYPE_ERASER) {
            // Finger input is intentionally reserved for navigation in this MVP.
            return true
        }
        updateContentRect()
        fun pointAt(x: Float, y: Float, pressure: Float): InkPoint {
            val nx = ((x - contentRect.left) / contentRect.width().coerceAtLeast(1f)).coerceIn(0f, 1f)
            val ny = ((y - contentRect.top) / contentRect.height().coerceAtLeast(1f)).coerceIn(0f, 1f)
            return InkPoint(nx, ny, pressure.coerceIn(0.05f, 1f))
        }
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                if (activeTool == InkTool.ERASER || toolType == MotionEvent.TOOL_TYPE_ERASER) {
                    eraseNear(pointAt(event.x, event.y, event.pressure))
                } else {
                    currentPoints = mutableListOf(pointAt(event.x, event.y, event.pressure))
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (activeTool == InkTool.ERASER) {
                    eraseNear(pointAt(event.x, event.y, event.pressure))
                } else {
                    for (h in 0 until event.historySize) {
                        currentPoints.add(pointAt(event.getHistoricalX(index, h), event.getHistoricalY(index, h), event.getHistoricalPressure(index, h)))
                    }
                    currentPoints.add(pointAt(event.getX(index), event.getY(index), event.getPressure(index)))
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                if (currentPoints.isNotEmpty()) {
                    strokes = (strokes + InkStroke(currentPoints.toList(), activeColor, brushWidthDp, activeTool)).toMutableList()
                    currentPoints.clear()
                    onStrokesChanged?.invoke(strokes.toList())
                }
                invalidate()
                return true
            }
        }
        return true
    }

    private fun eraseNear(point: InkPoint) {
        val hit = strokes.indexOfLast { stroke ->
            stroke.points.any { p ->
                hypot((p.x - point.x).toDouble(), (p.y - point.y).toDouble()) < 0.025
            }
        }
        if (hit >= 0) {
            strokes = strokes.toMutableList().also { it.removeAt(hit) }
            onStrokesChanged?.invoke(strokes.toList())
            invalidate()
        }
    }

    fun undo() {
        if (strokes.isNotEmpty()) {
            strokes = strokes.dropLast(1).toMutableList()
            onStrokesChanged?.invoke(strokes.toList())
            invalidate()
        }
    }

    fun clearInk() {
        strokes = mutableListOf()
        currentPoints.clear()
        onStrokesChanged?.invoke(emptyList())
        invalidate()
    }
}
