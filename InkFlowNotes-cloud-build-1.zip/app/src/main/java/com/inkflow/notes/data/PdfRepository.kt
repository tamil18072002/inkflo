package com.inkflow.notes.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.inkflow.notes.model.InkStroke
import com.inkflow.notes.model.InkTool
import java.io.File
import java.io.FileOutputStream
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState

class PdfRepository(private val context: Context) {
    init { PDFBoxResourceLoader.init(context.applicationContext) }

    private val pdfDir = File(context.filesDir, "pdfs").apply { mkdirs() }

    fun importPdf(uri: Uri): File {
        val name = "imported_${System.currentTimeMillis()}.pdf"
        val target = File(pdfDir, name)
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Could not open the selected PDF." }
            FileOutputStream(target).use { output -> input.copyTo(output) }
        }
        return target
    }

    fun renderFirstPage(file: File, maxDimension: Int = 1800): Bitmap {
        val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        pfd.use { descriptor ->
            PdfRenderer(descriptor).use { renderer ->
                require(renderer.pageCount > 0) { "This PDF has no pages." }
                renderer.openPage(0).use { page ->
                    val scale = (maxDimension.toFloat() / maxOf(page.width, page.height)).coerceAtMost(2.0f)
                    val bitmap = Bitmap.createBitmap(
                        (page.width * scale).toInt().coerceAtLeast(1),
                        (page.height * scale).toInt().coerceAtLeast(1),
                        Bitmap.Config.ARGB_8888
                    )
                    bitmap.eraseColor(Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return bitmap
                }
            }
        }
    }

    /**
     * Adds vector strokes to page 1 of a copy of the original PDF.
     * Coordinates are normalized to the displayed PDF page's fitted content rectangle.
     */
    fun exportAnnotatedCopy(source: File, output: File, strokes: List<InkStroke>) {
        PDDocument.load(source).use { document ->
            require(document.numberOfPages > 0) { "This PDF has no pages." }
            val page = document.getPage(0)
            val box: PDRectangle = page.cropBox
            PDPageContentStream(
                document, page, PDPageContentStream.AppendMode.APPEND, true, true
            ).use { stream ->
                strokes.filter { it.points.size >= 2 && it.tool != InkTool.ERASER }.forEach { stroke ->
                    val argb = stroke.color
                    val alpha = if (stroke.tool == InkTool.HIGHLIGHTER) 0.28f else 1f
                    val r = Color.red(argb) / 255f
                    val g = Color.green(argb) / 255f
                    val b = Color.blue(argb) / 255f
                    stream.setStrokingColor(r, g, b)
                    stream.setLineWidth((stroke.widthDp * box.width / 360f).coerceIn(0.4f, 18f))
                    stream.setLineCapStyle(1)
                    stream.setLineJoinStyle(1)
                    val gs = PDExtendedGraphicsState().apply { nonStrokingAlphaConstant = alpha; strokingAlphaConstant = alpha }
                    stream.setGraphicsStateParameters(gs)
                    val first = stroke.points.first()
                    stream.moveTo(first.x * box.width, box.height - first.y * box.height)
                    stroke.points.drop(1).forEach { point ->
                        stream.lineTo(point.x * box.width, box.height - point.y * box.height)
                    }
                    stream.stroke()
                }
            }
            document.save(output)
        }
    }
}
