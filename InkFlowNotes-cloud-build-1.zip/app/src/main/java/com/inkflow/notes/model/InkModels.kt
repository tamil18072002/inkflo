package com.inkflow.notes.model

import org.json.JSONArray
import org.json.JSONObject

data class InkPoint(val x: Float, val y: Float, val pressure: Float = 1f)

enum class InkTool { PEN, HIGHLIGHTER, ERASER }

data class InkStroke(
    val points: List<InkPoint>,
    val color: Int,
    val widthDp: Float,
    val tool: InkTool = InkTool.PEN
)

data class InkDocument(
    val id: String,
    val title: String,
    val strokes: List<InkStroke>,
    val updatedAt: Long = System.currentTimeMillis()
)

object InkJson {
    fun encode(document: InkDocument): String {
        val root = JSONObject()
            .put("id", document.id)
            .put("title", document.title)
            .put("updatedAt", document.updatedAt)
        val strokeArray = JSONArray()
        document.strokes.forEach { stroke ->
            val points = JSONArray()
            stroke.points.forEach { p ->
                points.put(JSONObject().put("x", p.x).put("y", p.y).put("pressure", p.pressure))
            }
            strokeArray.put(
                JSONObject()
                    .put("points", points)
                    .put("color", stroke.color)
                    .put("widthDp", stroke.widthDp)
                    .put("tool", stroke.tool.name)
            )
        }
        root.put("strokes", strokeArray)
        return root.toString()
    }

    fun decode(raw: String): InkDocument {
        val root = JSONObject(raw)
        val strokes = mutableListOf<InkStroke>()
        val strokeArray = root.optJSONArray("strokes") ?: JSONArray()
        for (i in 0 until strokeArray.length()) {
            val s = strokeArray.getJSONObject(i)
            val pointsJson = s.optJSONArray("points") ?: JSONArray()
            val points = mutableListOf<InkPoint>()
            for (j in 0 until pointsJson.length()) {
                val p = pointsJson.getJSONObject(j)
                points += InkPoint(
                    p.optDouble("x", 0.0).toFloat(),
                    p.optDouble("y", 0.0).toFloat(),
                    p.optDouble("pressure", 1.0).toFloat()
                )
            }
            val tool = runCatching { InkTool.valueOf(s.optString("tool", "PEN")) }.getOrDefault(InkTool.PEN)
            strokes += InkStroke(points, s.optInt("color", android.graphics.Color.BLACK),
                s.optDouble("widthDp", 3.0).toFloat(), tool)
        }
        return InkDocument(
            id = root.optString("id", "recovered"),
            title = root.optString("title", "Untitled"),
            strokes = strokes,
            updatedAt = root.optLong("updatedAt", System.currentTimeMillis())
        )
    }
}
