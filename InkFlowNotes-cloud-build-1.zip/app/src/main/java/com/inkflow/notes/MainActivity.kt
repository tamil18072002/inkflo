package com.inkflow.notes

import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.inkflow.notes.data.NoteRepository
import com.inkflow.notes.data.PdfRepository
import com.inkflow.notes.model.InkDocument
import com.inkflow.notes.model.InkStroke
import com.inkflow.notes.model.InkTool
import com.inkflow.notes.ui.DrawingSurface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { InkFlowApp() }
    }
}

private enum class Workspace { NOTES, PDF, SETTINGS }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun InkFlowApp() {
    val context = LocalContext.current
    val noteRepo = remember { NoteRepository(context) }
    val pdfRepo = remember { PdfRepository(context) }
    val scope = rememberCoroutineScope()
    var workspace by remember { mutableStateOf(Workspace.NOTES) }
    var notes by remember { mutableStateOf(noteRepo.list()) }
    var activeDoc by remember { mutableStateOf<InkDocument?>(null) }
    val strokes = remember { mutableStateListOf<InkStroke>() }
    var title by remember { mutableStateOf("Untitled note") }
    var activeTool by remember { mutableStateOf(InkTool.PEN) }
    var brushWidth by remember { mutableStateOf(3f) }
    var color by remember { mutableStateOf(Color.BLACK) }
    var surface by remember { mutableStateOf<DrawingSurface?>(null) }
    var pdfFile by remember { mutableStateOf<File?>(null) }
    var pdfBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var diagnostic by remember { mutableStateOf("Touch the screen with the pen to inspect input.") }
    var showNotes by remember { mutableStateOf(false) }
    var showColorMenu by remember { mutableStateOf(false) }
    var showToolMenu by remember { mutableStateOf(false) }
    var showSettingsHelp by remember { mutableStateOf(false) }
    var lastSaved by remember { mutableStateOf("Not saved yet") }

    val pdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                runCatching {
                    val copied = withContext(Dispatchers.IO) { pdfRepo.importPdf(uri) }
                    val bitmap = withContext(Dispatchers.IO) { pdfRepo.renderFirstPage(copied) }
                    pdfFile = copied
                    pdfBitmap = bitmap
                    strokes.clear()
                    workspace = Workspace.PDF
                    title = copied.name
                }.onFailure {
                    Toast.makeText(context, "PDF import failed: ${it.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
    val pdfExportPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val source = pdfFile
        if (uri != null && source != null) {
            scope.launch {
                runCatching {
                    val temp = withContext(Dispatchers.IO) {
                        val output = File(context.cacheDir, "inkflow_export_${System.currentTimeMillis()}.pdf")
                        pdfRepo.exportAnnotatedCopy(source, output, strokes.toList())
                        output
                    }
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri, "w").use { out ->
                            requireNotNull(out) { "Could not create output file." }
                            temp.inputStream().use { it.copyTo(out) }
                        }
                    }
                    temp.delete()
                    Toast.makeText(context, "Annotated PDF exported.", Toast.LENGTH_LONG).show()
                }.onFailure {
                    Toast.makeText(context, "Export failed: ${it.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    fun newNote() {
        val doc = noteRepo.create("Note ${notes.size + 1}")
        activeDoc = doc
        title = doc.title
        strokes.clear()
        pdfFile = null
        pdfBitmap = null
        workspace = Workspace.NOTES
        lastSaved = "New note"
    }

    fun openNote(doc: InkDocument) {
        activeDoc = doc
        title = doc.title
        strokes.clear()
        strokes.addAll(doc.strokes)
        pdfFile = null
        pdfBitmap = null
        workspace = Workspace.NOTES
        showNotes = false
    }

    fun saveCurrent() {
        val doc = activeDoc ?: noteRepo.create(title).also { activeDoc = it }
        val saved = doc.copy(title = title.ifBlank { "Untitled note" }, strokes = strokes.toList())
        noteRepo.save(saved)
        activeDoc = saved
        notes = noteRepo.list()
        lastSaved = "Saved locally"
        Toast.makeText(context, "Note saved on this device.", Toast.LENGTH_SHORT).show()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Column { Text("InkFlow Notes"); Text(if (workspace == Workspace.PDF) "PDF workspace" else if (workspace == Workspace.SETTINGS) "Pen diagnostics" else "Notebook studio", style = MaterialTheme.typography.labelSmall) } },
                actions = {
                    TextButton(onClick = { workspace = Workspace.NOTES }) { Text("Notes") }
                    TextButton(onClick = { pdfPicker.launch(arrayOf("application/pdf")) }) { Text("Open PDF") }
                    TextButton(onClick = { workspace = Workspace.SETTINGS }) { Text("Pen test") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).background(MaterialTheme.colorScheme.surface)) {
            if (workspace == Workspace.SETTINGS) {
                SettingsScreen(diagnostic = diagnostic, onBack = { workspace = Workspace.NOTES }, onClear = { surface?.clearInk(); strokes.clear() })
            } else if (workspace == Workspace.NOTES && activeDoc == null) {
                NotesHome(
                    notes = notes,
                    onNew = { newNote() },
                    onOpen = { openNote(it) },
                    onImportPdf = { pdfPicker.launch(arrayOf("application/pdf")) }
                )
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(onClick = { showNotes = true }) { androidx.compose.material3.Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(4.dp)); Text("Files") }
                    OutlinedButton(onClick = { activeTool = InkTool.PEN; surface?.activeTool = activeTool }) { androidx.compose.material3.Icon(Icons.Default.Draw, null); Text("Pen") }
                    Box {
                        OutlinedButton(onClick = { showToolMenu = true }) { androidx.compose.material3.Icon(Icons.Default.Brush, null); Text(activeTool.name) }
                        DropdownMenu(expanded = showToolMenu, onDismissRequest = { showToolMenu = false }) {
                            InkTool.entries.forEach { tool ->
                                DropdownMenuItem(text = { Text(tool.name.lowercase().replaceFirstChar { it.uppercase() }) }, onClick = {
                                    activeTool = tool
                                    surface?.activeTool = tool
                                    showToolMenu = false
                                })
                            }
                        }
                    }
                    Box {
                        OutlinedButton(onClick = { showColorMenu = true }) {
                            androidx.compose.material3.Icon(Icons.Default.ColorLens, null, tint = androidx.compose.ui.graphics.Color(color))
                            Text("Color")
                        }
                        DropdownMenu(expanded = showColorMenu, onDismissRequest = { showColorMenu = false }) {
                            listOf(Color.BLACK, Color.RED, Color.BLUE, Color.GREEN, Color.MAGENTA, Color.YELLOW).forEach { c ->
                                DropdownMenuItem(text = { Text(colorName(c)) }, onClick = {
                                    color = c; surface?.activeColor = c; showColorMenu = false
                                })
                            }
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    OutlinedButton(onClick = { surface?.undo(); if (surface == null && strokes.isNotEmpty()) strokes.removeAt(strokes.lastIndex) }) {
                        androidx.compose.material3.Icon(Icons.Default.Undo, null)
                    }
                    OutlinedButton(onClick = { saveCurrent() }) {
                        androidx.compose.material3.Icon(Icons.Default.Save, null); Text("Save")
                    }
                    if (workspace == Workspace.PDF && pdfFile != null) {
                        Button(onClick = { pdfExportPicker.launch("InkFlow-annotated.pdf") }) { Text("Export") }
                    }
                }
                if (workspace == Workspace.NOTES) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(title, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.weight(1f))
                        Text(lastSaved, style = MaterialTheme.typography.labelSmall)
                    }
                } else {
                    Text(pdfFile?.name ?: "Select a PDF", Modifier.padding(horizontal = 14.dp), style = MaterialTheme.typography.labelMedium)
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Brush size", style = MaterialTheme.typography.labelMedium)
                    Slider(
                        value = brushWidth, onValueChange = { brushWidth = it; surface?.brushWidthDp = it },
                        valueRange = 1f..18f, modifier = Modifier.weight(1f).padding(horizontal = 12.dp)
                    )
                    Text("${brushWidth.toInt()} dp")
                }
                AndroidView(
                    modifier = Modifier.fillMaxSize().padding(8.dp),
                    factory = { ctx ->
                        DrawingSurface(ctx).also { view ->
                            surface = view
                            view.strokes = strokes.toMutableList()
                            view.activeColor = color
                            view.brushWidthDp = brushWidth
                            view.activeTool = activeTool
                            view.backgroundBitmap = if (workspace == Workspace.PDF) pdfBitmap else null
                            view.onStrokesChanged = { changed ->
                                strokes.clear(); strokes.addAll(changed)
                                if (workspace == Workspace.NOTES) {
                                    val existing = activeDoc ?: noteRepo.create(title).also { activeDoc = it }
                                    noteRepo.save(existing.copy(title = title, strokes = changed))
                                    notes = noteRepo.list()
                                    lastSaved = "Autosaved"
                                }
                            }
                            view.onInputDiagnostic = { diagnostic = it }
                            view.onUndoRequested = { view.undo() }
                        }
                    },
                    update = { view ->
                        surface = view
                        view.activeColor = color
                        view.brushWidthDp = brushWidth
                        view.activeTool = activeTool
                        view.backgroundBitmap = if (workspace == Workspace.PDF) pdfBitmap else null
                        view.strokes = strokes.toMutableList()
                    }
                )
            }
        }
    }

    if (showNotes) {
        AlertDialog(
            onDismissRequest = { showNotes = false },
            title = { Text("Your notes") },
            text = {
                if (notes.isEmpty()) Text("No saved notes yet.")
                else LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(notes, key = { it.id }) { note ->
                        Card(onClick = { openNote(note) }, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text(note.title, style = MaterialTheme.typography.titleSmall)
                                Text("${note.strokes.size} strokes · ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(note.updatedAt))}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showNotes = false }) { Text("Close") } },
            dismissButton = { TextButton(onClick = { newNote(); showNotes = false }) { Text("New note") } }
        )
    }
    if (showSettingsHelp) {
        AlertDialog(onDismissRequest = { showSettingsHelp = false }, title = { Text("Pen button support") },
            text = { Text("Button events depend on HyperOS and the tablet firmware. Use Pen test while pressing each button. If no event appears, an ordinary app cannot remap a button that the system intercepts.") },
            confirmButton = { TextButton(onClick = { showSettingsHelp = false }) { Text("OK") } })
    }
}

@Composable
private fun NotesHome(
    notes: List<InkDocument>,
    onNew: () -> Unit,
    onOpen: (InkDocument) -> Unit,
    onImportPdf: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Your workspace", style = MaterialTheme.typography.headlineMedium)
        Text("Offline-first notes and PDF markup", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onNew) { androidx.compose.material3.Icon(Icons.Default.Add, null); Text("New note") }
            OutlinedButton(onClick = onImportPdf) { androidx.compose.material3.Icon(Icons.Default.Description, null); Text("Import PDF") }
        }
        Spacer(Modifier.height(18.dp))
        Text("Recent notes", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        if (notes.isEmpty()) {
            Text("No notes yet. Create one to start writing with your stylus.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(notes, key = { it.id }) { note ->
                    Card(onClick = { onOpen(note) }, modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            androidx.compose.material3.Icon(Icons.Default.Draw, null)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(note.title, style = MaterialTheme.typography.titleMedium)
                                Text("${note.strokes.size} strokes", style = MaterialTheme.typography.bodySmall)
                            }
                            TextButton(onClick = { onOpen(note) }) { Text("Open") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(diagnostic: String, onBack: () -> Unit, onClear: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("REDMI Smart Pen 1S", style = MaterialTheme.typography.headlineSmall)
        Text("Input diagnostics", style = MaterialTheme.typography.titleMedium)
        Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(12.dp)) {
            Text(diagnostic, Modifier.fillMaxWidth().padding(14.dp))
        }
        Text("Press each pen button while the tip touches the drawing surface. If the button state changes above, the app can potentially map that event. The current MVP maps the primary stylus button to undo as a basic proof of concept.", style = MaterialTheme.typography.bodyMedium)
        Text("Not yet implemented: persistent per-mode button profiles, long-press/double-press mappings, layers, lasso, and full multi-page PDF navigation.", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onBack) { Text("Back to workspace") }
            OutlinedButton(onClick = onClear) { Text("Clear ink") }
        }
    }
}

private fun colorName(color: Int): String = when (color) {
    Color.BLACK -> "Black"
    Color.RED -> "Red"
    Color.BLUE -> "Blue"
    Color.GREEN -> "Green"
    Color.MAGENTA -> "Magenta"
    Color.YELLOW -> "Yellow"
    else -> "Color"
}
