package com.inkflow.notes.data

import android.content.Context
import com.inkflow.notes.model.InkDocument
import com.inkflow.notes.model.InkJson
import java.io.File
import java.util.UUID

class NoteRepository(context: Context) {
    private val notesDir = File(context.filesDir, "notes").apply { mkdirs() }

    fun list(): List<InkDocument> = notesDir.listFiles { f -> f.extension == "json" }
        .orEmpty()
        .mapNotNull { file -> runCatching { InkJson.decode(file.readText()) }.getOrNull() }
        .sortedByDescending { it.updatedAt }

    fun create(title: String = "Untitled note"): InkDocument =
        InkDocument(UUID.randomUUID().toString(), title, emptyList())

    fun save(document: InkDocument) {
        val updated = document.copy(updatedAt = System.currentTimeMillis())
        val target = File(notesDir, "${updated.id}.json")
        val temp = File(notesDir, "${updated.id}.json.tmp")
        temp.writeText(InkJson.encode(updated))
        if (!temp.renameTo(target)) {
            temp.copyTo(target, overwrite = true)
            temp.delete()
        }
    }

    fun load(id: String): InkDocument? {
        val file = File(notesDir, "$id.json")
        return if (file.exists()) runCatching { InkJson.decode(file.readText()) }.getOrNull() else null
    }
}
