package com.inkflow.notes

import android.graphics.Color
import com.inkflow.notes.model.InkDocument
import com.inkflow.notes.model.InkJson
import com.inkflow.notes.model.InkPoint
import com.inkflow.notes.model.InkStroke
import com.inkflow.notes.model.InkTool
import org.junit.Assert.assertEquals
import org.junit.Test

class InkJsonTest {
    @Test fun documentRoundTrips() {
        val original = InkDocument(
            id = "abc", title = "Test",
            strokes = listOf(InkStroke(listOf(InkPoint(0.1f, 0.2f, 0.7f), InkPoint(0.8f, 0.9f)),
                Color.BLUE, 4f, InkTool.PEN)),
            updatedAt = 123L
        )
        val restored = InkJson.decode(InkJson.encode(original))
        assertEquals(original.id, restored.id)
        assertEquals(original.title, restored.title)
        assertEquals(original.strokes.size, restored.strokes.size)
        assertEquals(original.strokes[0].points.size, restored.strokes[0].points.size)
        assertEquals(original.strokes[0].color, restored.strokes[0].color)
    }
}
